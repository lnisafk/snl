#pragma once
#include <iostream>
#include <deque>
#include <unordered_map>
#include "AST.h"

static int debug2 = 1;
static int scopeno = 0;
static std::string passid;
static int findvarkind;
static int expectvarkind;
static int nextvarkind;
static int top, low;
static int arrayflag;

struct typeKind {
	int kind;			// 0:int 1:array 2:rec 3:id
	int low, top;

	typeKind(){}

	typeKind(int k, int l, int t)
		: kind(k), low(l), top(t) {}
};

class symbInfo {
	public:
		int sKind;			// 0:type 1:var 2:proc 3:prog 4:field
		typeKind *typtr;	// type&var 类型内部表示
		
		symbInfo(){}

		symbInfo(int kind, typeKind *typePtr) 
			: sKind(kind), typtr(typePtr) {}
};

typedef std::unordered_map<std::string, symbInfo> ssmap;

class symbolTable {
	public:
		std::deque<ssmap*> scope;

		void pushScope() {
			if (debug2 == 1) {
				std::cout << "SCOPE: PUSH " << ++scopeno <<std::endl;
			}
			ssmap* newScope = new ssmap();
			scope.push_back(newScope);
		}

		void popScope() {
			if (debug2 == 1) {
				std::cout << "SCOPE: POP " << scopeno-- << std::endl;
			}
			if (!scope.empty()) {
				delete scope.back();
				scope.pop_back();
			}
		}

		void insert(const std::string& id, const symbInfo& info) {
			if (debug2 == 1) {
				std::string idkind =	(info.sKind == 0) ? "TYPE" :
										(info.sKind == 1) ? "VAR" :
										(info.sKind == 2) ? "PROC" :
										(info.sKind == 3) ? "PROG" :
										"field";
				std::cout << "INSERT: " << idkind  << "\t" << id << std::endl;
				std::cout << "\tcurrunt scope: "<< scopeno << std::endl;
				std::cout << "\t----------------" << std::endl;
				for (const auto& pair : *scope.back()) {
					std::string eachkind =	(pair.second.sKind == 0) ? "TYPE" :
											(pair.second.sKind == 1) ? "VAR" :
											(pair.second.sKind == 2) ? "PROC" :
											(pair.second.sKind == 3) ? "PROG" :
											"field";
					std::cout << "\t" << eachkind << "\t" << pair.first << std::endl;
				}
				std::cout << "\t" << idkind << "\t" << id << std::endl;
				std::cout << "\t----------------" << std::endl;
			}
			(*scope.back())[id] = info;
		}

		void search(const std::string& id) {
			auto& curr = scope.back();
			if (debug2 == 1) {
				std::cout << "SEARCH: " << id << " IN " << scopeno << std::endl;
				std::cout << "\tcurrunt scope: "<< scopeno << std::endl;
				std::cout << "\t----------------" << std::endl;
				for (const auto& pair : *curr) {
					std::string eachkind =	(pair.second.sKind == 0) ? "TYPE" :
											(pair.second.sKind == 1) ? "VAR" :
											(pair.second.sKind == 2) ? "PROC" :
											(pair.second.sKind == 3) ? "PROG" :
											"field";
					std::cout << "\t" << eachkind << "\t" << pair.first << std::endl;
				}
				std::cout << "\t----------------" << std::endl;
			}
			auto it = curr->find(id);
			if (it != curr->end()) {
				std::cout << "ERROR: Existed ID." << std::endl;
				exit(1);
			}
			else return;
			/*
			while (!scope.empty()) {
				auto curr = scope.top();
				auto it = curr->find(id);
				if (it != curr->end()) {
					std::cout << "ERROR : Existed ID." << std::endl;
					exit(1);
				}
				else return;
			}
			*/
		}

		void ifdeclared(const std::string& id, int needtype) {
			if (debug2 == 1) {
				std::cout << "USE ID: " << id << std::endl;
			}
			int findno = scopeno;
			for (auto it = scope.rbegin(); it != scope.rend(); ++it) {
				if ((*it)->count(id) > 0) {
					if (debug2 == 1) {
						std::cout << "\tFinded in scope " << findno << std::endl;
					}
					auto& curr = *it;
					auto mapIt = curr->find(id);
					if (mapIt->second.sKind != needtype) {
						std::cout << "ERROR: Unexpect kind." << std::endl;
						exit(1);
					}
					if (mapIt->second.sKind == 1) {
						findvarkind = mapIt->second.typtr->kind;
					}
					return;
				}
				findno--;
			}
			std::cout << "ERROR: Undeclared ID." << std::endl;
			exit(1);
			/*
			while (!scope.empty()) {
				auto curr = scope.top();
				auto it = curr->find(id);
				if (it == curr->end()) {
					std::cout << "ERROR : Undeclared ID." << std::endl;
					exit(1);
				}
				else return;
			}
			*/
		}
};

static symbolTable symbTab;
static int tab = 0;

class BaseAST {
	public:
		virtual ~BaseAST() = default;

		virtual void Dump() const = 0;
};

// 开始
class CompUnitAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> program;

		void Dump() const override {
			program->Dump();
		}
};

// 总程序
class ProgramAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> programhead;
		std::unique_ptr<BaseAST> declarepart;
		std::unique_ptr<BaseAST> programbody;

		void Dump() const override {
			std::cout << "ProgramAST\n";
			tab++;
			programhead->Dump();
			declarepart->Dump();
			programbody->Dump();
			tab--;
		}
};

// 程序头
class ProgramHeadAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> programname;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProgramHeadAST\n";
			tab++;
			programname->Dump();
			tab--;
		}
};

// 3
class ProgramNameAST : public BaseAST {
	public:
		std::string id;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProgramNameAST\t";
			std::cout << id << std::endl;
			symbTab.pushScope();
			symbInfo info(3, nullptr);
			symbTab.insert(id, info);
		}
};

// 程序声明
class DeclarePartAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> typedec;
		std::unique_ptr<BaseAST> vardec;
		std::unique_ptr<BaseAST> procdec;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "DeclarePartAST\n";
			tab++;
			typedec->Dump();	
			vardec->Dump();
			procdec->Dump();	
			tab--;
		}
};

// 类型声明
class TypeDecAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> typedeclaration;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "TypeDecAST\n";
			tab++;
			if (typedeclaration != nullptr)			
				typedeclaration->Dump();
			tab--;
		}
};

class TypeDeclarationAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> typedeclist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "TypeDeclarationAST\n";
			tab++;
			typedeclist->Dump();
			tab--;
		}
};

class TypeDecListAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> type_id;
		std::unique_ptr<BaseAST> type_name;
		std::unique_ptr<BaseAST> typedecmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "TypeDecListAST\n";
			tab++;
			type_id->Dump();
			type_name->Dump();
			typedecmore->Dump();
			tab--;
		}
};

class TypeDecMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> typedeclist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "TypeDecMoreAST\n";
			tab++;
			if (typedeclist != nullptr)
				typedeclist->Dump();
			tab--;
		}
};

// 11
class TypeIdAST : public BaseAST {
	public:
		std::string id;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "TypeIdAST\t";
			std::cout << id << std::endl;
			symbTab.search(id);
			symbInfo info;
			info.sKind = 0;
			info.typtr = new typeKind(nextvarkind, 0, 0);
			symbTab.insert(id, info);
		}
};

// 12 14
// 类型
class TypeNameAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> BaseOrStruct;
		std::string id;
		int isid = 0;
		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			if (isid == 1) {
				std::cout << "TypeNameAST\t" << id << std::endl;
				symbTab.ifdeclared(id, 0);
				nextvarkind = 3;
			} else {
				std::cout << "TypeNameAST\n";
				tab++;
				BaseOrStruct->Dump();
				tab--;
			}
		}
};

class BaseTypeAST : public BaseAST {
	public:
		std::string IntOrChar;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "BaseTypeAST\t";
			nextvarkind = 0;
			if (IntOrChar == "integer")
				std::cout << "INT" << std::endl;
			else
				std::cout << "CHAR" << std::endl;
		}
};

class StructureTypeAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> ArrayOrRec;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "StructureTypeAST\n";
			tab++;
			ArrayOrRec->Dump();
			tab--;
		}
};

// 17
class ArrayTypeAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> low;
		std::unique_ptr<BaseAST> top;
		std::unique_ptr<BaseAST> basetype;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ArrayTypeAST\n";
			arrayflag = 1;
			tab++;
			low->Dump();
			top->Dump();
			basetype->Dump();
			tab--;
		}
};

class LowAST : public BaseAST {
	public:
		int intconst;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "LowAST\t" << intconst << std::endl;
			low = intconst;
		}
};

class TopAST : public BaseAST {
	public:
		int intconst;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "TopAST\t" << intconst << std::endl;
			top = intconst;
		}
};

class RecTypeAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> fielddeclist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "RecTypeAST\n";
			nextvarkind = 2;
			tab++;
			fielddeclist->Dump();
			tab--;
		}
};

// 23
class FieldDecListAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> BaseOrArray;
		std::unique_ptr<BaseAST> idlist;
		std::unique_ptr<BaseAST> fielddecmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "FieldDecListAST\n";
			tab++;
			BaseOrArray->Dump();
			idlist->Dump();
			fielddecmore->Dump();
			tab--;
		}
};

class FieldDecMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> fielddeclist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "FieldDecMoreAST\n";
			tab++;
			if (fielddeclist != nullptr)
				fielddeclist->Dump();
			tab--;
		}
};

// 27
class IdListAST : public BaseAST {
	public:
		std::string id;
		std::unique_ptr<BaseAST> idmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "IdListAST\n";
			tab++;
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << id << std::endl;
			symbTab.search(id);
			symbInfo info;
			info.sKind = 1;
			info.typtr = new typeKind(nextvarkind, low, top);
			symbTab.insert(id, info);
			tab--;
		}
};

class IdMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> idlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "IdMoreAST\n";
			tab++;
			if (idlist != nullptr)
			idlist->Dump();
			tab--;
		}
};

class VarDecAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> vardeclaration;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "VarDecAST\n";
			tab++;
			if (vardeclaration != nullptr)
				vardeclaration->Dump();
			tab--;
		}
};

class VarDeclarationAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> vardeclist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "VarDeclarationAST\n";
			tab++;
			vardeclist->Dump();
			tab--;
		}
};

class VarDecListAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> type_name;
		std::unique_ptr<BaseAST> varidlist;
		std::unique_ptr<BaseAST> vardecmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "VarDecListAST\n";
			tab++;
			type_name->Dump();
			varidlist->Dump();
			vardecmore->Dump();
			tab--;
		}
};

class VarDecMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> vardeclist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "VarDecMoreAST\n";
			tab++;
			if (vardeclist != nullptr)
				vardeclist->Dump();
			tab--;
		}
};

// 36
class VarIdListAST : public BaseAST {
	public:
		std::string id;
		std::unique_ptr<BaseAST> varidmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "VarIdListAST\n";
			tab++;
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << id << std::endl;
			symbTab.search(id);
			symbInfo info;
			info.sKind = 1;
			if (arrayflag == 1) {
				nextvarkind = 1;
				arrayflag = 0;
			}
			info.typtr = new typeKind(nextvarkind, low, top);
			symbTab.insert(id, info);
			varidmore->Dump();
			tab--;
		}
};

class VarIdMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> varidlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "VarIdMoreAST\n";
			tab++;
			if (varidlist != nullptr)
				varidlist->Dump();
			tab--;
		}
};

// 过程声明
class ProcDecAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> procdeclaration;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProcDecAST\n";
			tab++;
			if (procdeclaration != nullptr)
				procdeclaration->Dump();
			tab--;
		}
};

class ProcDeclarationAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> procname;
		std::unique_ptr<BaseAST> paramlist;
		std::unique_ptr<BaseAST> procdecpart;
		std::unique_ptr<BaseAST> procbody;
		std::unique_ptr<BaseAST> procdecmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProcDeclarationAST\n";
			tab++;
			procname->Dump();
			paramlist->Dump();
			procdecpart->Dump();
			procbody->Dump();
			procdecmore->Dump();
			tab--;
		}
};

// 42
class ProcDecMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> procdeclaration;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProcDecMoreAST\n";
			tab++;
			if (procdeclaration != nullptr)
				procdeclaration->Dump();
			tab--;
		}
};

// 44
class ProcNameAST : public BaseAST {
	public:
		std::string id;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProcNameAST\t" << id << std::endl;
			symbTab.search(id);
			symbInfo info(2, nullptr);
			symbTab.insert(id, info);
			symbTab.pushScope();
		}
};

// 参数声明
class ParamListAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> paramdeclist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ParamListAST\n";
			tab++;
			if (paramdeclist != nullptr)
				paramdeclist->Dump();
			tab--;
		}
};

class ParamDecListAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> param;
		std::unique_ptr<BaseAST> parammore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ParamDecListAST\n";
			tab++;
			param->Dump();
			parammore->Dump();
			tab--;
		}
};

class ParamMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> paramdeclist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ParamMoreAST\n";
			tab++;
			if (paramdeclist != nullptr)
				paramdeclist->Dump();
			tab--;
		}
};

class ParamAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> type_name;
		std::unique_ptr<BaseAST> formlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ParamAST\n";
			tab++;
			type_name->Dump();
			formlist->Dump();
			tab--;
		}
};

// 52
class FormListAST : public BaseAST {
	public:
		std::string id;
		std::unique_ptr<BaseAST> fidmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "FormListAST\n";
			tab++;
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << id << std::endl;
			symbInfo info;
			info.sKind = 1;
			info.typtr = new typeKind(nextvarkind, low, top);
			symbTab.insert(id, info);
			fidmore->Dump();
			tab--;
		}
};

// 53
class FidMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> formlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "FidMoreAST\n";
			tab++;
			if (formlist != nullptr)
				formlist->Dump();
			tab--;
		}
};

// 55
// 过程中的声明部分
class ProcDecPartAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> declarepart;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProcDecPartAST\n";
			tab++;
			declarepart->Dump();
			tab--;
		}
};

// 56
// 过程体
class ProcBodyAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> programbody;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProcBodyAST\n";
			tab++;
			programbody->Dump();
			tab--;
		}
};

// 57
// 主程序体
class ProgramBodyAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> stmlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ProgramBodyAST\n";
			tab++;
			stmlist->Dump();
			tab--;
			// scope pop
			symbTab.popScope();
		}
};

// 58
// 语句序列
class StmListAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> stm;
		std::unique_ptr<BaseAST> stmmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "StmListAST\n";
			tab++;
			stm->Dump();
			stmmore->Dump();
			tab--;
		}
};

class StmMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> stmlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "StmMoreAST\n";
			tab++;
			if (stmlist != nullptr)
				stmlist->Dump();
			tab--;
		}
};

// 61 66
// 语句
class StmAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> stmkind;
		std::string id;
		int ifasscall = 0;
		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "StmAST\n";
			tab++;
			if (ifasscall == 1) {
				for (int i = 0; i < tab; i++)
					std::cout << '\t';
				std::cout << id << std::endl;
				passid = id;
			}
			stmkind->Dump();
			tab--;
		}
};

class AssCallAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> AssOrCall;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "AssCallAST\n";
			tab++;
			AssOrCall->Dump();
			tab--;
		}
};

// 赋值语句
class AssignmentRestAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> varimore;
		std::unique_ptr<BaseAST> exp;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "AssignmentRestAST\n";
			symbTab.ifdeclared(passid, 1);
			if (findvarkind != 0) {
				std::cout<< "ERROR: Var type mismatch." << std::endl;
				exit(1);
			}
			tab++;
			varimore->Dump();
			exp->Dump();
			tab--;
		}
};

// 条件语句
class ConditionalStmAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> relexp;
		std::unique_ptr<BaseAST> stmlist1;
		std::unique_ptr<BaseAST> stmlist2;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ConditionalStmAST\n";
			tab++;
			relexp->Dump();
			stmlist1->Dump();
			stmlist2->Dump();
			tab--;
		}
};

// 循环语句
class LoopStmAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> relexp;
		std::unique_ptr<BaseAST> stmlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "LoopStmAST\n";
			tab++;
			relexp->Dump();
			stmlist->Dump();
			tab--;
		}
};

// 72
// 输入语句
class InputStmAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> invar;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "InputStmAST\n";
			tab++;
			invar->Dump();
			tab--;
		}
};

// 73
class InvarAST : public BaseAST {
	public:
		std::string id;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "InvarAST\t" << id << std::endl;
			symbTab.ifdeclared(id, 1);
			if (findvarkind != 0) {
				std::cout<< "ERROR: Var type mismatch." << std::endl;
				exit(1);
			}
		}
};

// 输出语句
class OutputStmAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> exp;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "OutputStmAST\n";
			tab++;
			exp->Dump();
			tab--;
		}
};

// 返回语句
class ReturnStmAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> exp;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ReturnStmAST\n";
			tab++;
			exp->Dump();
			tab--;
		}
};

// 过程调用语句
class CallStmRestAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> actparamlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "CallStmRestAST\n";
			symbTab.ifdeclared(passid, 2);
			tab++;
			actparamlist->Dump();
			tab--;
		}
};

class ActParamListAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> exp;
		std::unique_ptr<BaseAST> actparammore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ActParamListAST\n";
			tab++;
			if (exp != nullptr) {
				exp->Dump();
				actparammore->Dump();
			}
			tab--;
		}
};

class ActParamMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> actparamlist;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ActParamMoreAST\n";
			tab++;
			if (actparamlist != nullptr)
				actparamlist->Dump();
			tab--;
		}
};

// 条件表达式
class RelExpAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> exp;
		std::unique_ptr<BaseAST> otherrele;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "RelExpAST\n";
			tab++;
			exp->Dump();
			otherrele->Dump();
			tab--;
		}
};

class OtherRelEAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> cmpop;
		std::unique_ptr<BaseAST> exp;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "OtherRelEAST\n";
			tab++;
			cmpop->Dump();
			exp->Dump();
			tab--;
		}
};

// 算术表达式
class ExpAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> term;
		std::unique_ptr<BaseAST> otherterm;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "ExpAST\n";
			tab++;
			term->Dump();
			otherterm->Dump();
			tab--;
		}
};

class OtherTermAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> addop;
		std::unique_ptr<BaseAST> exp;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "OtherTermAST\n";
			tab++;
			if (addop != nullptr) {
				addop->Dump();
				exp->Dump();
			}
			tab--;
		}
};

// 项
class TermAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> factor;
		std::unique_ptr<BaseAST> otherfactor;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "TermAST\n";
			tab++;
			factor->Dump();
			otherfactor->Dump();
			tab--;
		}
};

class OtherFactorAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> multop;
		std::unique_ptr<BaseAST> term;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "OtherFactorAST\n";
			tab++;
			if (multop != nullptr) {
				multop->Dump();
				term->Dump();
			}			
			tab--;
		}
};

// 因子
class FactorAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> ExpOrVar;
		int intconst;
		int isint = 0;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			if (isint == 1) {
				std::cout << "FactorAST\t" << intconst << std::endl;
			} else {
				std::cout << "FactorAST\n";
				tab++;
				ExpOrVar->Dump();
				tab--;
			}
		}
};

// 92
class VariableAST : public BaseAST {
	public:
		std::string id;
		std::unique_ptr<BaseAST> varimore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "VariableAST\t" << id << std::endl;
			symbTab.ifdeclared(id, 1);
			tab++;
			varimore->Dump();
			tab--;
		}
};

// 93 94 95
class VariMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> more;
		int expect;
		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "VariMoreAST\n";
			std::cout << findvarkind << expect;
			if (findvarkind != expect) {
				std::cout<< "ERROR: Var type mismatch." << std::endl;
				exit(1);
			}
			tab++;
			if (more != nullptr)
				more->Dump();
			tab--;
		}
};

// 96
class FieldVarAST : public BaseAST {
	public:
		std::string id;
		std::unique_ptr<BaseAST> fieldvarmore;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "FieldVarAST\t" << id << std::endl;
			symbTab.ifdeclared(id, 4);
			tab++;
			fieldvarmore->Dump();
			tab--;
		}
};

class FieldVarMoreAST : public BaseAST {
	public:
		std::unique_ptr<BaseAST> exp;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "FieldVarMoreAST\n";
			tab++;
			if (exp != nullptr)
				exp->Dump();
			tab--;
		}
};

class CmpOpAST : public BaseAST {
	public:
		char type;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "CmpOpAST\t" << type << std::endl;
		}
};

class AddOpAST : public BaseAST {
	public:
		char type;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "AddOpAST\t" << type << std::endl;
		}
};

class MultOpAST : public BaseAST {
	public:
		char type;

		void Dump() const override {
			for (int i = 0; i < tab; i++)
				std::cout << '\t';
			std::cout << "MultOpAST\t" << type << std::endl;
		}
};

