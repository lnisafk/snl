#include <iostream>
#include <cstdio>
#include <memory>
#include <cstring>
#include "AST.h"

using namespace std;

extern FILE *yyin;
extern int yyparse(unique_ptr<BaseAST> &ast);
extern string debug;

int main(int argc, const char *argv[]) {
	yyin = fopen(argv[1], "r");
	auto op = argv[2];
	unique_ptr<BaseAST> ast;
	auto ret = yyparse(ast);
	if (strcmp(op, "-ast") == 0)
		ast->Dump();
	if (strcmp(op, "-tl") == 0)
		cout << debug << endl;
	return 0;
}
